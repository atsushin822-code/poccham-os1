#!/bin/bash
set -e
echo "=== OHD Bridge Daily ISO Build Started: $(date) ==="
df -h
# Need ~3GB free for build
sudo lb build 2>&1 | tee build.log
echo "=== Build finished ==="
ls -lh *.iso 2>&1 | head -5
sha256sum *.iso 2>&1 | head -5
